##  A13 & A14 Bug Fix Realme C21Y

This module provides fixes for common issues found on Android 11 & Android 12 GSI Rom on the Realme C21Y device, specifically related to brightness and OTG functionality.

### Changelog

- Testing update button
- Remake banner on github
- Add verified on github
- Fix downloas eror on magisk app
- Fix DAC Dongle 

## Credits
- OTG Fix By Mr.J
- DAC Fix By FandyID (Telegram)